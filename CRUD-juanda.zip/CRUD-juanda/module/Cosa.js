const loadForm = (data) => {
    const {
        first_name,
        last_name,
        phone,
        address,
        type_id
    } = data;

}